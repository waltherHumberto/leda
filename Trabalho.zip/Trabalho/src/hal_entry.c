/* HAL-only entry function */
#include "hal_data.h"
#include "math.h"

#define     M_PI                    3.14159265358979323846

#define     LED1                    IOPORT_PORT_06_PIN_00
#define     LED3                    IOPORT_PORT_06_PIN_02
#define     LEDAZ                   IOPORT_PORT_06_PIN_04
#define     LEDVE                   IOPORT_PORT_06_PIN_05
#define     MAX_VALUE               4095
#define     MAX_POINTS              1000
#define     DELTA_TETA              (2*M_PI/MAX_POINTS)
#define     _ltrans(x,xi,xm,yi,ym)  (long)((long)((x-xi)*(ym-yi))/(xm-xi)+yi)
#define     _ftrans(x,xi,xm,yi,ym)  (float)((float)((float)(x-xi)*(float)(ym-yi))/(float)(xm-xi)+yi)
#define CONSTANTE  1

// Tick Rate
#define COUNTS_PER_MILLISECOND  (120E6 / 1000)
int counts=0;

uint16_t vector_sin[MAX_POINTS];
float adc_data=0;
uint16_t val0 =0 ,val1 =0 ,val2=0,val3=0;
ioport_level_t Led_VD=IOPORT_LEVEL_HIGH, Led_AM=IOPORT_LEVEL_HIGH;

// Flags
volatile bool transmitComplete;

ssp_err_t ssp_err;
adc_sample_state_t adc_modify_sample_state;


int _write( char *buffer, int count);

int _write( char *buffer, int count)
{
    // As far as I know, there isn't a way to retrieve how many
    // bytes were send on using the uart->write function if it does not return
    // SSP_SUCCESS (unless we want to use the tx interrupt function and a global counter
    // so, we will send each character one by one instead.
    int bytesTransmitted = 0;

    for (int i = 0; i < count; i++)
    {
        // Start Transmission
        transmitComplete = false;
        g_uart.p_api->write (g_uart.p_ctrl, (uint8_t const *) (buffer + i), 1);
        while (!transmitComplete)
        {
        }

        bytesTransmitted++;
    }

    return bytesTransmitted;
}

// Callback Function for UART interrupts
void user_uart_callback(uart_callback_args_t * p_args)
{
    // Get Event Type
    switch (p_args->event)
    {
        // Transmission Complete
        case UART_EVENT_TX_COMPLETE:
            transmitComplete = true;
        break;
        default:
        break;
    }
}



void hal_entry(void)
{
    int p1=0,p2=0,p3=0,p4 = 0;
    // Inicializacao dos drivers
    g_adc0.p_api->open(g_adc0.p_ctrl, g_adc0.p_cfg);
    g_uart.p_api->open (g_uart.p_ctrl, g_uart.p_cfg);
    g_timer0_agt.p_api->open(g_timer0_agt.p_ctrl, g_timer0_agt.p_cfg);

    g_adc0.p_api->scanCfg(g_adc0.p_ctrl, g_adc0.p_channel_cfg);
    g_adc0.p_api->scanStart(g_adc0.p_ctrl);

    for(;;)
    {
        _write("test",5);
        p1= val0*CONSTANTE;
        p2= val1*CONSTANTE;
        p3= val2*CONSTANTE;
        p4= val3*CONSTANTE;

//        if(p1<10||p2<10||p3<10||p4<10){
//            g_ioport.p_api->pinWrite(LEDAZ,0);
//            g_ioport.p_api->pinWrite(LEDVE,0);}
//            else {
//                g_ioport.p_api->pinWrite(LEDAZ,1);
                          g_ioport.p_api->pinWrite(LEDVE,1);
        R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_SECONDS);


    }

}

void isr_irq_wave_generator(timer_callback_args_t *p_args)
{
    SSP_PARAMETER_NOT_USED(p_args);
    static int i=0;
    static uint32_t k=0;
    if (++k==50)
    {
        k = 0;
        Led_VD = !Led_VD;
        g_ioport.p_api->pinWrite(LED1,Led_VD);

    }
    i++;
    i%=MAX_POINTS;
}

void isr_irq_ADC000(adc_callback_args_t *p_args)
{
    SSP_PARAMETER_NOT_USED(p_args);
    static uint32_t k=0;
    if (++k==200000)
    {
        k = 0;
        Led_AM = !Led_AM;
        g_ioport.p_api->pinWrite(LED3,Led_AM);

    }

    ssp_err =  g_adc0.p_api->read(g_adc0.p_ctrl, ADC_REG_CHANNEL_0,&val0);
    if( SSP_SUCCESS != ssp_err )
        {
            __BKPT(1);
        }

    ssp_err =   g_adc0.p_api->read(g_adc0.p_ctrl, ADC_REG_CHANNEL_1,&val1);
    if( SSP_SUCCESS != ssp_err )
        {
            __BKPT(1);
        }

    ssp_err =  g_adc0.p_api->read(g_adc0.p_ctrl, ADC_REG_CHANNEL_2,&val2);
    if( SSP_SUCCESS != ssp_err )
        {
            __BKPT(1);
        }

    ssp_err =  g_adc0.p_api->read(g_adc0.p_ctrl, ADC_REG_CHANNEL_3,&val3);
    if( SSP_SUCCESS != ssp_err )
        {
            __BKPT(1);
        }

    ssp_err =  g_adc0.p_api->scanStart(g_adc0.p_ctrl);
    if( SSP_SUCCESS != ssp_err )
        {
            __BKPT(1);
        }

}

