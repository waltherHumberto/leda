/* HAL-only entry function */
#include "hal_data.h"
#include "math.h"

#define     M_PI                    3.14159265358979323846

#define     LED1                    IOPORT_PORT_06_PIN_00
#define     LED3                    IOPORT_PORT_06_PIN_02
#define     MAX_VALUE               4095
#define     MAX_POINTS              1000
#define     DELTA_TETA              (2*M_PI/MAX_POINTS)
#define     _ltrans(x,xi,xm,yi,ym)  (long)((long)((x-xi)*(ym-yi))/(xm-xi)+yi)
#define     _ftrans(x,xi,xm,yi,ym)  (float)((float)((float)(x-xi)*(float)(ym-yi))/(float)(xm-xi)+yi)

uint16_t vector_sin[MAX_POINTS];
float adc_data=0;
uint16_t val0 =0 ,val1 =0 ,val2=0,val3=0;
ioport_level_t Led_VD=IOPORT_LEVEL_HIGH, Led_AM=IOPORT_LEVEL_HIGH;

void hal_entry(void)
{
    uint32_t i;

    // Inicializacao dos drivers
    g_adc0.p_api->open(g_adc0.p_ctrl, g_adc0.p_cfg);
    g_timer0_agt.p_api->open(g_timer0_agt.p_ctrl, g_timer0_agt.p_cfg);

    g_adc0.p_api->scanCfg(g_adc0.p_ctrl, g_adc0.p_channel_cfg);
    g_adc0.p_api->scanStart(g_adc0.p_ctrl);
    for(;;)
    {
    }
}

void isr_irq_wave_generator(timer_callback_args_t *p_args)
{
    SSP_PARAMETER_NOT_USED(p_args);
    static int i=0;
    static uint32_t k=0;
    if (++k==50)
    {
        k = 0;
        Led_VD = !Led_VD;
        g_ioport.p_api->pinWrite(LED1,Led_VD);
    }
    i++;
    i%=MAX_POINTS;
}

void isr_irq_ADC000(adc_callback_args_t *p_args)
{
    SSP_PARAMETER_NOT_USED(p_args);
    uint16_t data=0;
    static uint32_t k=0;
    if (++k==200000)
    {
        k = 0;
        Led_AM = !Led_AM;
        g_ioport.p_api->pinWrite(LED3,Led_AM);

    }
    g_adc0.p_api->read(g_adc0.p_ctrl, ADC_REG_CHANNEL_0,&val0);

    g_adc0.p_api->read(g_adc0.p_ctrl, ADC_REG_CHANNEL_1,&val1);

    g_adc0.p_api->read(g_adc0.p_ctrl, ADC_REG_CHANNEL_2,&val2);

    g_adc0.p_api->read(g_adc0.p_ctrl, ADC_REG_CHANNEL_3,&val3);

    g_adc0.p_api->scanStart(g_adc0.p_ctrl);

}

